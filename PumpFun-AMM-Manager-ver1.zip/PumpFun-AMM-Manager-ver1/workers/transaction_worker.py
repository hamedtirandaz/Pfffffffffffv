"""
==============================================================
Transaction Worker

==============================================================
"""

from PySide6.QtCore import QObject
from PySide6.QtCore import QRunnable
from PySide6.QtCore import Signal

import asyncio


class TransactionWorkerSignals(QObject):

    finished = Signal(str)

    error = Signal(str)


class TransactionWorker(QRunnable):

    def __init__(

        self,

        transaction_manager,

        transaction,

    ):

        super().__init__()

        self.manager = transaction_manager

        self.transaction = transaction

        self.signals = TransactionWorkerSignals()

    def run(self):

        try:

            signature = asyncio.run(

                self.manager.send_and_confirm(

                    self.transaction

                )

            )

            self.signals.finished.emit(

                signature

            )

        except Exception as e:

            self.signals.error.emit(

                str(e)

            )