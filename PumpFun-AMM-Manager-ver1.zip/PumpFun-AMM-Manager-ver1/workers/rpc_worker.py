"""
==============================================================
RPC Worker

اجرای عملیات RPC در Thread جداگانه

==============================================================
"""

from PySide6.QtCore import QObject
from PySide6.QtCore import QRunnable
from PySide6.QtCore import Signal


class RPCWorkerSignals(QObject):

    finished = Signal(object)

    error = Signal(str)


class RPCWorker(QRunnable):

    def __init__(self, coroutine):

        super().__init__()

        self.coroutine = coroutine

        self.signals = RPCWorkerSignals()

    def run(self):

        import asyncio

        try:

            result = asyncio.run(
                self.coroutine
            )

            self.signals.finished.emit(result)

        except Exception as e:

            self.signals.error.emit(
                str(e)
            )