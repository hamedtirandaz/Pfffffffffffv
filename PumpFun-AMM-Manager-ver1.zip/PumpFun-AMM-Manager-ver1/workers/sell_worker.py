"""
==============================================================
Sell Worker

==============================================================
"""

from PySide6.QtCore import QObject
from PySide6.QtCore import QRunnable
from PySide6.QtCore import Signal

import asyncio


class SellWorkerSignals(QObject):

    finished = Signal(str)

    error = Signal(str)


class SellWorker(QRunnable):

    def __init__(

        self,

        amm_service,

        transaction,

    ):

        super().__init__()

        self.amm = amm_service

        self.transaction = transaction

        self.signals = SellWorkerSignals()

    def run(self):

        try:

            signature = asyncio.run(

                self.amm.sell(

                    self.transaction

                )

            )

            self.signals.finished.emit(

                signature

            )

        except Exception as e:

            self.signals.error.emit(

                str(e)

            )