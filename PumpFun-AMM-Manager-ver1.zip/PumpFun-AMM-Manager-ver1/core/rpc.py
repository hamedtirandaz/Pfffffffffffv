# ==========================================================
# rpc.py
# Unified Solana RPC Layer (Clean + Production Ready)
# ==========================================================
"""
==============================================================
core/rpc.py

لایه ارتباط با Solana RPC

سازگار با:
    solana-py >= 0.40
    solders >= 0.27

این کلاس تنها نقطه ارتباط برنامه با RPC است.
تمام Service ها فقط باید از این کلاس استفاده کنند.

==============================================================
"""

from __future__ import annotations

import ast
import base64
import base58

from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solders.transaction import VersionedTransaction

from solana.rpc.async_api import AsyncClient

from constants import RPCConstants
from logger import get_logger

logger = get_logger()


class SolanaRPC:
    """
    Async RPC Wrapper

    تمام ارتباط برنامه با شبکه سولانا از طریق این کلاس انجام می‌شود.
    """

    # ------------------------------------------------------
    # Constructor
    # ------------------------------------------------------

    def __init__(self, rpc_url: str | None = None):

        self.rpc_url = rpc_url or RPCConstants.DEFAULT

        self.client = AsyncClient(
            endpoint=self.rpc_url,
            timeout=RPCConstants.TIMEOUT,
        )

        logger.info(
            "RPC initialized: %s",
            self.rpc_url
        )

    # ======================================================
    # Connection
    # ======================================================

    async def close(self):
        """
        بستن اتصال RPC
        """

        await self.client.close()

        logger.info("RPC connection closed")

    # ======================================================
    # Wallet Helpers
    # ======================================================

    @staticmethod
    def parse_private_key(private_key: str) -> Keypair:
        """
        تبدیل رشته کلید خصوصی به Keypair

        فرمت‌های قابل قبول:

        - Base58
        - Hex
        - Python List
        """

        private_key = private_key.strip()

        if private_key.startswith("["):

            raw = bytes(
                ast.literal_eval(private_key)
            )

        elif (
            len(private_key) == 64
            and all(
                c in "0123456789abcdefABCDEF"
                for c in private_key
            )
        ):

            raw = bytes.fromhex(private_key)

        else:

            raw = base58.b58decode(private_key)

        return Keypair.from_bytes(raw)

    # ------------------------------------------------------

    @staticmethod
    def encode_transaction(
        tx: VersionedTransaction
    ) -> str:
        """
        تبدیل تراکنش به Base64
        """

        return base64.b64encode(
            bytes(tx)
        ).decode("utf-8")

    # ======================================================
    # Balance
    # ======================================================

    async def get_balance(
        self,
        pubkey: Pubkey,
    ) -> float:
        """
        دریافت موجودی SOL
        """

        logger.debug(
            "Getting balance: %s",
            pubkey,
        )

        response = await self.client.get_balance(
            pubkey
        )

        lamports = response.value

        sol = lamports / 1_000_000_000

        logger.info(
            "Balance %.6f SOL",
            sol,
        )

        return sol

    # ======================================================
    # Latest Blockhash
    # ======================================================

    async def get_latest_blockhash(
        self,
    ) -> str:
        """
        دریافت آخرین Blockhash
        """

        response = await self.client.get_latest_blockhash()

        blockhash = str(
            response.value.blockhash
        )

        logger.debug(
            "Latest blockhash: %s",
            blockhash,
        )

        return blockhash
    
    # ======================================================
    # Account Info
    # ======================================================

    async def get_account_info(
        self,
        pubkey: Pubkey,
    ):
        """
        دریافت اطلاعات کامل یک Account
        """

        logger.debug(
            "Getting account info: %s",
            pubkey,
        )

        response = await self.client.get_account_info(
            pubkey
        )

        return response.value

    # ======================================================
    # Token Accounts
    # ======================================================

    async def get_token_accounts(
        self,
        owner: Pubkey,
    ):
        """
        دریافت Token Account های کیف پول

        خروجی:
            RPC Response.value
        """

        logger.debug(
            "Getting token accounts: %s",
            owner,
        )

        response = await self.client.get_token_accounts_by_owner_json_parsed(
            owner,
            program_id=Pubkey.from_string(
                "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            ),
        )

        return response.value

    # ======================================================
    # Transaction
    # ======================================================

    async def send_transaction(
        self,
        tx: VersionedTransaction,
        skip_preflight: bool = False,
    ) -> str:
        """
        ارسال تراکنش
        """

        logger.info(
            "Sending transaction..."
        )

        resp = self.client.send_raw_transaction(bytes(tx))

        signature = str(response.value)

        logger.info(
            "Transaction sent: %s",
            signature,
        )

        return signature

    # ======================================================
    # Simulation
    # ======================================================

    async def simulate_transaction(
        self,
        tx: VersionedTransaction,
    ):
        """
        شبیه سازی تراکنش
        """

        logger.debug(
            "Simulating transaction..."
        )

        response = await self.client.simulate_transaction(
            tx,
        )

        return response.value

    # ======================================================
    # Confirm Transaction
    # ======================================================

    async def confirm_transaction(
        self,
        signature: str,
    ) -> bool:
        """
        منتظر تایید تراکنش
        """

        logger.info(
            "Confirming transaction..."
        )

        response = await self.client.confirm_transaction(
            signature,
        )

        return bool(response.value)

    # ======================================================
    # Health
    # ======================================================

    async def health_check(
        self,
    ) -> bool:
        """
        بررسی سلامت RPC
        """

        try:

            response = await self.client.get_health()

            return response.value == "ok"

        except Exception as exc:

            logger.error(
                "RPC health check failed: %s",
                exc,
            )

            return False

    # ======================================================
    # Slot
    # ======================================================

    async def get_slot(self) -> int:
        """
        دریافت Slot فعلی شبکه
        """

        response = await self.client.get_slot()

        return response.value

    # ======================================================
    # Block Height
    # ======================================================

    async def get_block_height(self) -> int:
        """
        دریافت Block Height
        """

        response = await self.client.get_block_height()

        return response.value

    # ======================================================
    # Raw Client
    # ======================================================

    def raw(self) -> AsyncClient:
        """
        دسترسی مستقیم به AsyncClient
        """

        return self.client