from solana.rpc.api import Client


class RPCExecutor:
    def __init__(self, rpc_url):
        self.client = Client(rpc_url)

    def send_and_confirm(self, tx, signer):
        try:
            resp = self.client.send_transaction(tx, signer)
            signature = resp.value

            # confirm (mainnet safe)
            self.client.confirm_transaction(signature)

            return {
                "signature": str(signature),
                "status": "confirmed"
            }

        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }