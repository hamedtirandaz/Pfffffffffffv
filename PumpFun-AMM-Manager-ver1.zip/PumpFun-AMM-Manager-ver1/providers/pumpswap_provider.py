"""
PumpSwap Provider
"""

from .pumpfun_provider import PumpFunProvider


class PumpSwapProvider(PumpFunProvider):

    pass