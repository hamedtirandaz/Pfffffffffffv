"""
==============================================================

Pump.fun Provider

در آینده به Pump.fun SDK متصل می‌شود.

==============================================================
"""

from logger import get_logger

from .base_provider import BaseProvider

logger = get_logger()


class PumpFunProvider(BaseProvider):

    def __init__(self, rpc):

        self.rpc = rpc

        logger.info("PumpFunProvider initialized")

    async def buy(self, transaction):

        logger.info("Pump.fun BUY")

        return await self.rpc.send_transaction(
            transaction
        )

    async def sell(self, transaction):

        logger.info("Pump.fun SELL")

        return await self.rpc.send_transaction(
            transaction
        )

    async def simulate(self, transaction):

        return await self.rpc.simulate_transaction(
            transaction
        )