"""
==============================================================

Base Provider

تمام Provider ها باید از این کلاس ارث‌بری کنند.

==============================================================
"""

from abc import ABC
from abc import abstractmethod


class BaseProvider(ABC):

    @abstractmethod
    async def buy(self, *args, **kwargs):
        pass

    @abstractmethod
    async def sell(self, *args, **kwargs):
        pass

    @abstractmethod
    async def simulate(self, *args, **kwargs):
        pass