"""
Jupiter Provider
"""

from .pumpfun_provider import PumpFunProvider


class JupiterProvider(PumpFunProvider):

    pass