"""
Raydium Provider
"""

from .pumpfun_provider import PumpFunProvider


class RaydiumProvider(PumpFunProvider):

    pass