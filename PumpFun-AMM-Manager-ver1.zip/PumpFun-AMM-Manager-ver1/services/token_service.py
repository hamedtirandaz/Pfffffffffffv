"""
==============================================================
services/token_service.py

مدیریت Token

فعلاً فقط اسکلت اولیه

بعداً:

- Create Token
- Mint
- Metadata
- Freeze
- Burn

==============================================================
"""

from logger import get_logger

logger = get_logger()


class TokenService:

    def __init__(self, rpc):

        self.rpc = rpc

        logger.info("TokenService initialized")

    async def get_token_info(self, mint):

        """
        دریافت اطلاعات Mint
        """

        return await self.rpc.get_account_info(
            mint
        )

    async def token_exists(self, mint):

        account = await self.get_token_info(mint)

        return account is not None