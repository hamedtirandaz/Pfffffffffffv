"""
==============================================================
services/trading_service.py

Trading Service

وظایف:

- ساخت تراکنش خرید
- ساخت تراکنش فروش
- ارسال تراکنش
- شبیه سازی
- تایید تراکنش

==============================================================
"""

from logger import get_logger

logger = get_logger()


class TradingService:

    def __init__(self, rpc, wallet_service):

        self.rpc = rpc
        self.wallet = wallet_service

        logger.info("TradingService initialized")

    async def simulate(self, transaction):

        return await self.rpc.simulate_transaction(
            transaction
        )

    async def send(self, transaction):

        return await self.rpc.send_transaction(
            transaction
        )

    async def confirm(self, signature):

        return await self.rpc.confirm_transaction(
            signature
        )

    async def send_and_confirm(self, transaction):

        signature = await self.send(transaction)

        ok = await self.confirm(signature)

        if not ok:
            raise RuntimeError(
                "Transaction confirmation failed."
            )

        return signature