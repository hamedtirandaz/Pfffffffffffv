"""
==============================================================
gui.pages

این پکیج شامل تمام صفحات Wizard برنامه است.

هر صفحه در فایل جداگانه قرار دارد تا نگهداری پروژه
ساده‌تر و توسعه آن آسان‌تر باشد.

==============================================================
"""

from .base_page import BaseWizardPage
from .welcome_page import WelcomePage
from .wallet_page import WalletPage
#from .rpc_page import RPCPage

# صفحات بعداً اضافه خواهند شد.

# from .token_page import TokenPage
# from .pool_page import PoolPage
# from .buy_page import BuyPage
# from .review_page import ReviewPage
# from .finish_page import FinishPage


__all__ = [

    "BaseWizardPage",

    "WelcomePage",

    "WalletPage",

 #   "RPCPage",

]