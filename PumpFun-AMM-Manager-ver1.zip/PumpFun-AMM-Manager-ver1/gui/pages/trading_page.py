# ==========================================================
# trading_page.py
# Trading UI (AMM / Bot Control Panel - Base Version)
# ==========================================================

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QLineEdit, QFormLayout, QGroupBox, QMessageBox
)

from solders.pubkey import Pubkey

from logger import get_logger

logger = get_logger()


class TradingPage(QWidget):
    """
    صفحه ترید (فعلاً پایه - بعداً AMM کامل می‌شود)
    """

    def __init__(self, rpc, wallet_service=None, parent=None):
        super().__init__(parent)

        self.rpc = rpc
        self.wallet_service = wallet_service

        self.init_ui()

    # ------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        # ===== TOKEN INPUT =====
        group = QGroupBox("Trading Panel")

        form = QFormLayout()

        self.token_input = QLineEdit()
        self.token_input.setPlaceholderText("Token mint address")

        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText("Amount (SOL)")

        form.addRow("Token:", self.token_input)
        form.addRow("Amount:", self.amount_input)

        group.setLayout(form)

        # ===== BUTTONS =====
        self.btn_buy = QPushButton("BUY")
        self.btn_sell = QPushButton("SELL")
        self.btn_simulate = QPushButton("SIMULATE")

        self.btn_buy.clicked.connect(self.buy)
        self.btn_sell.clicked.connect(self.sell)
        self.btn_simulate.clicked.connect(self.simulate)

        layout.addWidget(group)
        layout.addWidget(self.btn_buy)
        layout.addWidget(self.btn_sell)
        layout.addWidget(self.btn_simulate)

        self.status = QLabel("Ready")
        layout.addWidget(self.status)

    # ------------------------------------------------------
    def buy(self):
        """
        فعلاً placeholder برای AMM buy
        """
        token = self.token_input.text().strip()

        if not token:
            QMessageBox.warning(self, "Error", "Token required")
            return

        self.status.setText(f"BUY request: {token}")
        logger.info("BUY clicked: %s", token)

        # اینجا بعداً وصل میشه به amm_service

    # ------------------------------------------------------
    def sell(self):
        token = self.token_input.text().strip()

        if not token:
            QMessageBox.warning(self, "Error", "Token required")
            return

        self.status.setText(f"SELL request: {token}")
        logger.info("SELL clicked: %s", token)

    # ------------------------------------------------------
    def simulate(self):
        """
        شبیه‌سازی معامله (بعداً RPC simulate_transaction)
        """
        token = self.token_input.text().strip()

        if not token:
            QMessageBox.warning(self, "Error", "Token required")
            return

        self.status.setText(f"SIMULATING: {token}")
        logger.info("SIMULATE: %s", token)