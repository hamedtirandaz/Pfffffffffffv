"""
==============================================================
wallet_page.py

Wallet Wizard Page

وظایف:

✔ ذخیره Private Key
✔ اعتبارسنجی Private Key
✔ نمایش Address
✔ نمایش Balance
✔ Refresh Balance

Author:
Hamed Tirandaz
==============================================================
"""

from __future__ import annotations

from PySide6.QtWidgets import (

    QLabel,

    QPushButton,

    QLineEdit,

    QCheckBox,

)

from gui.pages.base_page import BasePage


class WalletPage(BasePage):

    TITLE = "Wallet"

    SUBTITLE = "Wallet Configuration"

    DESCRIPTION = """
Configure your Solana wallet.

Your Private Key is stored only on your computer.

Never share your Private Key with anyone.
"""

    # ======================================================
    # Constructor
    # ======================================================

    def __init__(self, config, parent=None):

        self.config = config

        super().__init__(parent)

    # ======================================================
    # Build UI
    # ======================================================

    def build_body(self):

        self.build_private_key_card()

        self.build_wallet_info_card()

    # ======================================================
    # Private Key Card
    # ======================================================

    def build_private_key_card(self):

        group = self.ui.card("Private Key")

        form = self.ui.form()

        self.key_input = QLineEdit()

        self.key_input.setEchoMode(
            QLineEdit.Password
        )

        form.addRow(

            "Private Key:",

            self.key_input

        )

        self.show_key = QCheckBox(

            "Show Private Key"

        )

        self.show_key.toggled.connect(

            self.toggle_private_key_visibility

        )

        form.addRow(

            "",

            self.show_key

        )

        group.layout().addLayout(

            form

        )

        self.save_btn = QPushButton(

            "Save"

        )

        self.clear_btn = QPushButton(

            "Clear"

        )

        self.save_btn.clicked.connect(

            self.save_key

        )

        self.clear_btn.clicked.connect(

            self.clear_key

        )

        group.layout().addLayout(

            self.ui.button_row(

                self.save_btn,

                self.clear_btn

            )

        )

        self.add_widget(group)

    # ======================================================
    # Wallet Information Card
    # ======================================================

    def build_wallet_info_card(self):
        """
        ساخت کارت اطلاعات کیف پول
        """

        group = self.ui.card("Wallet Information")

        form = self.ui.form()

        # -----------------------------------------
        # Address
        # -----------------------------------------

        self.address_lbl = QLabel("-")

        self.address_lbl.setTextInteractionFlags(
            self.address_lbl.textInteractionFlags()
        )

        form.addRow(
            "Address:",
            self.address_lbl
        )

        # -----------------------------------------
        # Balance
        # -----------------------------------------

        self.balance_lbl = QLabel("-")

        form.addRow(
            "Balance:",
            self.balance_lbl
        )

        # -----------------------------------------
        # Network
        # -----------------------------------------

        self.network_lbl = QLabel("Mainnet")

        form.addRow(
            "Network:",
            self.network_lbl
        )

        group.layout().addLayout(form)

        # -----------------------------------------
        # Buttons
        # -----------------------------------------

        self.refresh_btn = QPushButton(
            "Refresh Balance"
        )

        self.refresh_btn.clicked.connect(
            self.refresh_balance
        )

        group.layout().addLayout(

            self.ui.button_row(
                self.refresh_btn
            )

        )

        self.add_widget(group)

    # ======================================================
    # Slots
    # ======================================================

    def toggle_private_key_visibility(
        self,
        checked: bool
    ):
        """
        نمایش یا مخفی کردن کلید خصوصی
        """

        mode = (
            QLineEdit.Normal
            if checked
            else QLineEdit.Password
        )

        self.key_input.setEchoMode(mode)

    # ======================================================
    # UI Helpers
    # ======================================================

    def set_wallet_address(
        self,
        address: str
    ):
        """
        نمایش آدرس کیف پول
        """

        self.address_lbl.setText(address)

    def set_balance(
        self,
        balance: str
    ):
        """
        نمایش موجودی
        """

        self.balance_lbl.setText(balance)

    def set_network(
        self,
        network: str
    ):
        """
        نمایش شبکه
        """

        self.network_lbl.setText(network)

    # ======================================================
    # Load
    # ======================================================

    def initializePage(self):
        """
        هنگام ورود به صفحه
        """

        super().initializePage()

        self.load_key()

    def load_key(self):
        """
        بارگذاری کلید ذخیره شده
        """

        if self.config is None:
            return

        private_key = self.config.get(
            "private_key",
            ""
        )

        self.key_input.setText(private_key)

        if private_key:

            self.set_status("Wallet loaded.")

        else:

            self.set_status("No wallet configured.")

    # ======================================================
    # Save
    # ======================================================

    def save_key(self):
        """
        ذخیره کلید خصوصی
        """

        key = self.key_input.text().strip()

        if not key:

            self.show_error(
                "Private Key is empty."
            )

            return

        self.config.set(
            "private_key",
            key
        )

        self.config.save()

        self.show_success(
            "Private Key saved."
        )

    # ======================================================
    # Clear
    # ======================================================

    def clear_key(self):
        """
        حذف کلید ذخیره شده
        """

        self.key_input.clear()

        self.address_lbl.setText("-")

        self.balance_lbl.setText("-")

        self.config.set(
            "private_key",
            ""
        )

        self.config.save()

        self.show_info(
            "Private Key removed."
        )

    # ======================================================
    # Refresh
    # ======================================================

    def refresh_balance(self):
        """
        بروزرسانی موجودی

        در نسخه‌های بعدی از WalletService
        استفاده خواهد شد.
        """

        self.show_busy(
            "Loading balance..."
        )

        #
        # TODO
        #
        # WalletService.get_balance()
        #
        # Address
        # Balance
        #

        self.hide_busy()

    # ======================================================
    # Validation
    # ======================================================

    def validatePage(self):
        """
        بررسی قبل از رفتن به صفحه بعد
        """

        key = self.key_input.text().strip()

        if not key:

            self.show_error(
                "Please enter your Private Key."
            )

            return False

        return True