"""
==============================================================
wizard.py

Wizard اختصاصی برنامه

ساختار:

+----------------------------------------------------------+
| Navigation |              Page Area                      |
|            |                                             |
|            |                                             |
|            |                                             |
+----------------------------------------------------------+
| Back              Next              Finish      Cancel   |
+----------------------------------------------------------+

Author:
Hamed Tirandaz
==============================================================
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QWidget,
    QListWidget,
    QListWidgetItem,
    QStackedWidget,
    QPushButton,
    QLabel,
    QHBoxLayout,
    QVBoxLayout,
    QFrame
)

from context import WizardContext

from constants import (
    AppConstants,
    UIConstants
)

from gui.pages.welcome_page import WelcomePage
from gui.pages.wallet_page import WalletPage


class PumpWizard(QDialog):

    def __init__(self, config, parent=None):

        super().__init__(parent)

        self.config = config

        self.context = WizardContext()

        self.current_index = 0

        self._setup_window()

        self._build_ui()

        self._create_pages()

    # =====================================================
    # UI
    # =====================================================

    def _build_ui(self):

        root = QVBoxLayout(self)

        root.setContentsMargins(12,12,12,12)
        root.setSpacing(10)

        # ----------------------------------------
        # قسمت اصلی
        # ----------------------------------------

        content = QHBoxLayout()

        root.addLayout(content)

        # ========================================
        # Navigation
        # ========================================

        self.navigation = QListWidget()

        self.navigation.setFixedWidth(220)

        self.navigation.setSpacing(4)

        content.addWidget(self.navigation)

        # ========================================
        # Separator
        # ========================================

        line = QFrame()

        line.setFrameShape(QFrame.VLine)

        content.addWidget(line)

        # ========================================
        # Pages
        # ========================================

        self.stack = QStackedWidget()

        content.addWidget(
            self.stack,
            1
        )

        # ----------------------------------------
        # Footer
        # ----------------------------------------

        footer = QHBoxLayout()

        root.addLayout(footer)

        self.step_label = QLabel()

        footer.addWidget(self.step_label)

        footer.addStretch()

        self.back_btn = QPushButton("◀ Back")

        self.next_btn = QPushButton("Next ▶")

        self.finish_btn = QPushButton("Finish")

        self.cancel_btn = QPushButton("Cancel")

        footer.addWidget(self.back_btn)

        footer.addWidget(self.next_btn)

        footer.addWidget(self.finish_btn)

        footer.addWidget(self.cancel_btn)


    # =====================================================
    # Pages
    # =====================================================

    def _create_pages(self):

        self.pages = [

            ("Welcome",
             WelcomePage()),

            ("Wallet",
             WalletPage(self.config)),

        ]

        for title, page in self.pages:

            self.navigation.addItem(
                QListWidgetItem(title)
            )

            self.stack.addWidget(page)

        self.navigation.setCurrentRow(0)

        self.stack.setCurrentIndex(0)

        self.step_label.setText(

            f"Step 1 / {len(self.pages)}"

        )


        # ----------------------------------------
        # Signals
        # ----------------------------------------

        self.back_btn.clicked.connect(
            self.go_back
        )

        self.next_btn.clicked.connect(
            self.go_next
        )

        self.finish_btn.clicked.connect(
            self.finish
        )

        self.cancel_btn.clicked.connect(
            self.reject
        )

        self.navigation.currentRowChanged.connect(
            self.change_page
        )
        
        self.update_ui()

    # =====================================================
    # Update UI
    # =====================================================

    def update_ui(self):

        total = len(self.pages)

        self.step_label.setText(
            f"Step {self.current_index + 1} / {total}"
        )

        self.back_btn.setEnabled(
            self.current_index > 0
        )

        self.next_btn.setEnabled(
            self.current_index < total - 1
        )

        self.finish_btn.setEnabled(
            self.current_index == total - 1
        )


    # =====================================================
    # Change Page
    # =====================================================

    def change_page(self, index):

        if index < 0:
            return

        if index >= len(self.pages):
            return

        self.current_index = index

        self.stack.setCurrentIndex(index)

        self.navigation.blockSignals(True)
        self.navigation.setCurrentRow(index)
        self.navigation.blockSignals(False)

        self.update_ui()


    # =====================================================
    # Next
    # =====================================================

    def go_next(self):

        if self.current_index >= len(self.pages) - 1:
            return

        self.current_index += 1

        self.navigation.setCurrentRow(
            self.current_index
        )


    # =====================================================
    # Back
    # =====================================================

    def go_back(self):

        if self.current_index == 0:
            return

        self.current_index -= 1

        self.navigation.setCurrentRow(
            self.current_index
        )


    # =====================================================
    # Finish
    # =====================================================

    def finish(self):

        self.accept()

    # =====================================================
    # Context
    # =====================================================

    def get_context(self):

        return self.context


    def reset_context(self):

        self.context.reset()

        
