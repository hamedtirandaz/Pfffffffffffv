from core.token_manager import TokenManager


class TokenPage:
    def __init__(self, wallet, rpc_url):
        self.token_manager = TokenManager(wallet, rpc_url)

    def create_token(self):
        result = self.token_manager.create_token()
        return result