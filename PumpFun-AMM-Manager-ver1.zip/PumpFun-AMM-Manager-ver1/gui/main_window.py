"""
==============================================================
main_window.py

پنجره اصلی برنامه

وظایف این فایل:

✔ ساخت پنجره اصلی
✔ ساخت MenuBar
✔ ساخت ToolBar
✔ ساخت StatusBar
✔ ساخت Central Widget
✔ اجرای Wizard در اولین اجرا
✔ مدیریت رویدادهای اصلی برنامه

نکته:

هیچ منطق مربوط به ساخت توکن، خرید، فروش، RPC،
کیف پول یا Workerها نباید داخل این فایل نوشته شود.

==============================================================
"""

from PySide6.QtCore import Qt

from PySide6.QtGui import QAction
from constants import UIConstants

from PySide6.QtWidgets import (

    QMainWindow,

    QWidget,

    QLabel,

    QVBoxLayout,

    QMessageBox,

    QToolBar,

    QStatusBar,

)

from constants import (

    AppConstants,

)

from gui.wizard import PumpWizard


# ==========================================================
# Main Window
# ==========================================================

class MainWindow(QMainWindow):

    """
    پنجره اصلی برنامه
    """

    # ------------------------------------------------------

    def __init__(self, config):

        super().__init__()

        # ذخیره تنظیمات برنامه

        self.config = config

        # وضعیت اجرای Wizard

        self.wizard = None

        # ساخت رابط کاربری

        self.setup_window()

        self.create_menu()

        self.create_toolbar()

        self.create_statusbar()

        self.create_central_widget()

        # بررسی اولین اجرای برنامه

        self.check_first_run()

    # ======================================================
    # تنظیمات اولیه پنجره
    # ======================================================

    def setup_window(self):

        self.setWindowTitle(

            AppConstants.WINDOW_TITLE

        )

        self.resize(
            UIConstants.WINDOW_WIDTH,
            UIConstants.WINDOW_HEIGHT
        )

    # ======================================================
    # ساخت MenuBar
    # ======================================================

    def create_menu(self):

        menu = self.menuBar()

        # -------------------------

        file_menu = menu.addMenu("File")

        tools_menu = menu.addMenu("Tools")

        wallet_menu = menu.addMenu("Wallet")

        help_menu = menu.addMenu("Help")

        # -------------------------
        # File
        # -------------------------

        wizard_action = QAction(

            "Setup Wizard",

            self

        )

        wizard_action.triggered.connect(

            self.show_wizard

        )

        file_menu.addAction(

            wizard_action

        )

        file_menu.addSeparator()

        exit_action = QAction(

            "Exit",

            self

        )

        exit_action.triggered.connect(

            self.close

        )

        file_menu.addAction(

            exit_action

        )

        # -------------------------
        # Help
        # -------------------------

        about_action = QAction(

            "About",

            self

        )

        about_action.triggered.connect(

            self.show_about

        )

        help_menu.addAction(

            about_action

        )

    # ======================================================
    # Toolbar
    # ======================================================

    def create_toolbar(self):

        toolbar = QToolBar()

        toolbar.setMovable(False)

        self.addToolBar(toolbar)

        wizard_action = QAction(

            "Wizard",

            self

        )

        wizard_action.triggered.connect(

            self.show_wizard

        )

        toolbar.addAction(

            wizard_action

        )

    # ======================================================
    # StatusBar
    # ======================================================

    def create_statusbar(self):

        status = QStatusBar()

        self.setStatusBar(status)

        status.showMessage(

            "Ready"

        )

    # ======================================================
    # Central Widget
    # ======================================================

    def create_central_widget(self):

        widget = QWidget()

        layout = QVBoxLayout(widget)

        title = QLabel(

            "Pump.fun AMM Manager"

        )

        title.setAlignment(

            Qt.AlignCenter

        )

        layout.addStretch()

        layout.addWidget(title)

        layout.addStretch()

        self.setCentralWidget(widget)

    # ======================================================
    # اولین اجرا
    # ======================================================

    def check_first_run(self):

        """
        اگر برنامه برای اولین بار اجرا شود،
        Wizard نمایش داده می‌شود.
        """

        first_run = self.config.get(

            "first_run",

            True

        )

        if first_run:

            self.show_wizard()

    # ======================================================
    # نمایش Wizard
    # ======================================================

    def show_wizard(self):

        self.wizard = PumpWizard(self.config, self)

        result = self.wizard.exec()

        # اگر Wizard کامل شد

        if result:

            self.config.set(

                "first_run",

                False

            )

            self.config.save()

            self.statusBar().showMessage(

                "Wizard Completed"

            )

    # ======================================================
    # About
    # ======================================================

    def show_about(self):

        QMessageBox.information(

            self,

            "About",

            f"""

{AppConstants.NAME}

Version :

{AppConstants.VERSION}

Python + PySide6

"""

        )

    # ======================================================
    # هنگام بستن برنامه
    # ======================================================

    def closeEvent(self, event):

        """وقتی پنجره بسته می‌شود"""
        # توقف تمام پردازش‌های پس‌زمینه
        self.cleanup()
        # بستن برنامه
        QApplication.quit()

        event.accept()
    def cleanup(self):
        """پاکسازی منابع قبل از بسته شدن"""
        logger.info("Cleaning up resources...")
        # اگر ویزارد باز است، ببندید
        if hasattr(self, 'wizard') and self.wizard is not None:
            try:
                self.wizard.close()
                self.wizard.deleteLater()
            except:
                pass
        # اگر سرویس‌ها نیاز به پاکسازی دارند
        # مثلاً: ذخیره تنظیمات، بستن اتصالات و ...
        self.save_settings()
        logger.info("Cleanup completed")
    
    def save_settings(self):
        """ذخیره تنظیمات جاری"""
        try:
            if hasattr(self, 'config'):
                self.config.save()
                logger.info("Settings saved")
        except Exception as e:
            logger.error(f"Error saving settings:%s ",e)