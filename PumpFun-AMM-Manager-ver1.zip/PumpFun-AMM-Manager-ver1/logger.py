"""
==============================================================
logger.py

مدیریت سیستم لاگ برنامه

وظایف

✔ ایجاد Logger اصلی برنامه

✔ ذخیره Log داخل فایل

✔ نمایش Log در Console

✔ پشتیبانی از Thread

✔ آماده برای اتصال به LogWidget

Author:
Hamed Tirandaz

==============================================================
"""

from pathlib import Path

import logging

from logging.handlers import RotatingFileHandler

from constants import (
    APP_NAME,
    LoggerConstants,
    PathConstants,
)
# ==========================================================
# Logger Manager
# ==========================================================

class LoggerManager:
    """
    مدیریت Logger برنامه
    """

    def __init__(self):

        self.logger = logging.getLogger(APP_NAME)


        self.logger.setLevel(
            logging.DEBUG
        )

        self.logger.propagate = False
        self.widget = None

        self._initialize()

    # ------------------------------------------------------

    def _initialize(self):
        """
        ایجاد Handler ها
        """

        # جلوگیری از ایجاد دوباره Handler ها

        if self.logger.handlers:

            return

        # -------------------------------
        # پوشه Log
        # -------------------------------

        log_path = Path(PathConstants.LOG_FILE)

        log_path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        # -------------------------------
        # فایل Log
        # -------------------------------

        # فایل لاگ

        file_handler = RotatingFileHandler(

            log_path,

            maxBytes=5 * 1024 * 1024,

            backupCount=5,

            encoding="utf-8"

        )

        # -------------------------------
        # Console
        # -------------------------------

        console_handler = logging.StreamHandler()

        # -------------------------------
        # Format
        # -------------------------------

        formatter = logging.Formatter(

            "[%(asctime)s] "

            "%(levelname)s "

            "%(name)s "

            "%(message)s",

            datefmt=LoggerConstants.DATETIME_FORMAT

        )

        file_handler.setFormatter(
            formatter
        )

        console_handler.setFormatter(
            formatter
        )

        # -------------------------------
        # اضافه کردن Handler ها
        # -------------------------------

        self.logger.addHandler(
            file_handler
        )

        self.logger.addHandler(
            console_handler
        )

    # ======================================================
    # متدهای اصلی
    # ======================================================

    def debug(self, msg, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self.logger.error(msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        self.logger.critical(msg, *args, **kwargs)

    def exception(self, msg, *args, **kwargs):
        self.logger.exception(msg, *args, **kwargs)

    # ======================================================
    # LogWidget
    # ======================================================

    def attach_widget(self, widget):
        """
        در آینده:

        اتصال LogWidget

        """

        self.widget = widget

    # ======================================================
    # گرفتن Logger
    # ======================================================

    def get_logger(self):

        return self.logger


# ==========================================================
# Singleton
# ==========================================================

_logger = LoggerManager()


# ==========================================================
# توابع کمکی
# ==========================================================

def debug(msg, *args, **kwargs):
    _logger.debug(msg, *args, **kwargs)


def info(msg, *args, **kwargs):
    _logger.info(msg, *args, **kwargs)


def warning(msg, *args, **kwargs):
    _logger.warning(msg, *args, **kwargs)


def error(msg, *args, **kwargs):
    _logger.error(msg, *args, **kwargs)


def critical(msg, *args, **kwargs):
    _logger.critical(msg, *args, **kwargs)


def exception(msg, *args, **kwargs):
    _logger.exception(msg, *args, **kwargs)



def get_logger():
    return _logger.get_logger()