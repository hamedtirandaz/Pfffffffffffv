"""
==========================================================
Pump.fun AMM Manager
Entry Point (Refactored for new architecture)

وظایف آن عبارت‌اند از:

1- ساخت برنامه Qt
2- بارگذاری تنظیمات
3- بارگذاری استایل برنامه
4- راه‌اندازی Logger
5- ساخت پنجره اصلی
6- مدیریت خطاهای پیش‌بینی نشده
==========================================================
"""

import os
os.system('cls' if os.name == 'nt' else 'clear')


from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import traceback

# کلاس اصلی برنامه PySide6
from PySide6.QtWidgets import QApplication, QMessageBox

# فایل‌های پروژه
from config import Config
from constants import APP_NAME
from logger import get_logger
from gui.style import load_stylesheet
from gui.main_window import MainWindow

# services (NEW ARCHITECTURE)
from core.rpc import SolanaRPC
from services.wallet_service import WalletService
from services.trading_service import TradingService
from services.token_service import TokenService
from services.amm_service import AMMService

# ---------------------------------------------------------
# ساخت Logger
# ---------------------------------------------------------
# از این شیء در تمام برنامه برای ثبت لاگ استفاده می‌کنیم.
logger = get_logger()


# ---------------------------------------------------------
# مدیریت خطاهای پیش‌بینی نشده
# ---------------------------------------------------------
# اگر هرجای برنامه خطایی رخ دهد که try/except آن را نگرفته باشد،
# این تابع اجرا خواهد شد.
# علاوه بر ذخیره لاگ، پنجره خطا نیز به کاربر نمایش داده می‌شود.
# ---------------------------------------------------------
def exception_hook(exc_type, exc_value, exc_traceback):

    # تبدیل خطا به متن قابل نمایش
    error_text = "".join(
        traceback.format_exception(
            exc_type,
            exc_value,
            exc_traceback
        )
    )

    # ذخیره در فایل لاگ
    logger.exception(error_text)
    app = QApplication.instance()

    if app is not None:
        # نمایش پنجره خطا
        QMessageBox.critical(
            None,
            "Unexpected Error",
            error_text
        )
    else:
         # اگر هنوز Qt ساخته نشده،
        # فقط خطا را روی ترمینال چاپ می‌کنیم.
        print(error_text)


# ---------------------------------------------------------
# ساخت برنامه Qt
# ---------------------------------------------------------
def create_application():

    logger.info("Creating QApplication...")

    app = QApplication(sys.argv)

    # نام برنامه
    app.setApplicationName(APP_NAME)

    # بارگذاری فایل استایل (QSS)
    stylesheet = load_stylesheet()

    # اگر فایل استایل وجود داشت
    if stylesheet:
        app.setStyleSheet(stylesheet)

    logger.info("Application ready")

    return app


# ---------------------------------------------------------
# بارگذاری تنظیمات
# ---------------------------------------------------------
def initialize_config():

    logger.info("=" * 60)
    logger.info("Initializing configuration")

    # ساخت شیء تنظیمات
    config = Config()

    # خواندن فایل config.json
    config.load()

    logger.info("Config loaded")

    return config

# ---------------------------------------------------------
def build_services(config):
    """
    ساخت تمام service layer ها (DI container ساده)
    """


    logger.info("Building services layer...")

    try:
        from constants import RPCConstants
        rpc_url = config.get("rpc_url") or RPCConstants.DEFAULT
        rpc = SolanaRPC(rpc_url)

        wallet_service = WalletService(rpc)
        trading_service = TradingService(rpc, wallet_service)
        token_service = TokenService(rpc)
        amm_service = AMMService(rpc, wallet_service, trading_service)

        logger.info("Services initialized")

        return {
            "rpc": rpc,
            "wallet": wallet_service,
            "trading": trading_service,
            "token": token_service,
            "amm": amm_service,
        }
    except Exception:
        logger.exception("Failed to initialize services.")
        raise

# ---------------------------------------------------------
# تابع اصلی برنامه
# ---------------------------------------------------------
def main():

    # تعیین Handler سراسری خطاها
    sys.excepthook = exception_hook

   # ساخت QApplication
    app = create_application()

#    logger.info("Program Started")

    # خواندن تنظیمات
    config = initialize_config()

 
    services = build_services(config)

    # ساخت پنجره اصلی
 #   window = MainWindow(
 #       config=config,
 #       rpc=services["rpc"],
 #       wallet_service=services["wallet"],
 #       trading_service=services["trading"],
 #       token_service=services["token"],
 #       amm_service=services["amm"],
 #   )
    window = MainWindow(config)

    # نمایش پنجره
    window.show()

#    logger.info("Main Window Shown")

    # ورود به Event Loop
    exit_code = app.exec()

    logger.info("Program Closed")

    # خروج از برنامه
    sys.exit(exit_code)


# ---------------------------------------------------------
# نقطه شروع برنامه
# ---------------------------------------------------------
# فقط زمانی اجرا می‌شود که فایل main.py مستقیماً اجرا شود.
# اگر این فایل توسط فایل دیگری import شود،
# این قسمت اجرا نخواهد شد.
# ---------------------------------------------------------
if __name__ == "__main__":
    main()