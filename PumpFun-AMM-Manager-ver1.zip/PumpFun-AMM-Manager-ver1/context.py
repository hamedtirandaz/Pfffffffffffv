"""
==============================================================
context.py

نگهداری اطلاعات مشترک Wizard

این کلاس تمام اطلاعاتی که کاربر در مراحل مختلف Wizard
وارد می‌کند را نگهداری می‌کند.

تمام صفحات Wizard به همین شیء دسترسی دارند.

==============================================================
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class WizardContext:
    """
    اطلاعات مشترک Wizard
    """

    # -------------------------------
    # اطلاعات کیف پول
    # -------------------------------

    wallet: Optional[object] = None

    private_key: str = ""

    wallet_path: str = ""

    rpc_url: str = ""

    network: str = "mainnet"

    # -------------------------------
    # اطلاعات توکن
    # -------------------------------

    token_name: str = ""

    symbol: str = ""

    description: str = ""

    decimals: int = 9

    supply: int = 0

    image_path: str = ""

    metadata_uri: str = ""

    # -------------------------------
    # اطلاعات استخر
    # -------------------------------

    pool_sol: float = 0.0

    pool_token: float = 0.0

    priority_fee: int = 10000

    slippage: float = 5.0

    # -------------------------------
    # تنظیمات خرید اولیه
    # -------------------------------

    buy_amount: float = 0.0

    buy_wallet_count: int = 0

    # -------------------------------
    # اطلاعات متفرقه
    # -------------------------------

    notes: dict = field(default_factory=dict)

    def reset(self):
        """
        بازگرداندن تمام مقادیر به حالت اولیه
        """

        self.__dict__.update(WizardContext().__dict__)